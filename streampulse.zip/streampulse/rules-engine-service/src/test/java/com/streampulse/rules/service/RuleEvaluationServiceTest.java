package com.streampulse.rules.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.streampulse.contracts.event.AlertEvent;
import com.streampulse.contracts.event.AlertSeverity;
import com.streampulse.contracts.event.MonitoringEvent;
import com.streampulse.contracts.event.MonitoringEventType;
import com.streampulse.rules.entity.AlertRule;
import com.streampulse.rules.entity.RuleComparator;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;

class RuleEvaluationServiceTest {

    private RuleService ruleService;
    private IdempotencyService idempotencyService;
    private KafkaTemplate<String, AlertEvent> alertKafkaTemplate;
    private RuleEvaluationService evaluationService;

    @SuppressWarnings("unchecked")
    @BeforeEach
    void setUp() {
        ruleService = mock(RuleService.class);
        idempotencyService = mock(IdempotencyService.class);
        alertKafkaTemplate = mock(KafkaTemplate.class);
        when(alertKafkaTemplate.send(any(String.class), any(String.class), any(AlertEvent.class)))
                .thenReturn(CompletableFuture.completedFuture(mock(SendResult.class)));
        evaluationService = new RuleEvaluationService(ruleService, idempotencyService, alertKafkaTemplate);
    }

    @Test
    void publishesAlertWhenRuleBreached() {
        UUID tenantId = UUID.randomUUID();
        AlertRule rule = new AlertRule(UUID.randomUUID(), tenantId, "High CPU", "cpu.usage.percent",
                RuleComparator.GREATER_THAN, 90.0, AlertSeverity.CRITICAL, true, Instant.now());
        when(ruleService.activeRulesForTenant(tenantId)).thenReturn(List.of(rule));

        MonitoringEvent event = new MonitoringEvent("evt-1", tenantId.toString(), "web-01",
                MonitoringEventType.CPU_USAGE, "cpu.usage.percent", 97.0, Instant.now(), Map.of());

        evaluationService.evaluate(event);

        verify(alertKafkaTemplate).send(eq("streampulse.alerts"), eq(tenantId.toString()), any(AlertEvent.class));
    }

    @Test
    void doesNotPublishWhenNoRuleBreached() {
        UUID tenantId = UUID.randomUUID();
        AlertRule rule = new AlertRule(UUID.randomUUID(), tenantId, "High CPU", "cpu.usage.percent",
                RuleComparator.GREATER_THAN, 90.0, AlertSeverity.CRITICAL, true, Instant.now());
        when(ruleService.activeRulesForTenant(tenantId)).thenReturn(List.of(rule));

        MonitoringEvent event = new MonitoringEvent("evt-2", tenantId.toString(), "web-01",
                MonitoringEventType.CPU_USAGE, "cpu.usage.percent", 40.0, Instant.now(), Map.of());

        evaluationService.evaluate(event);

        verify(alertKafkaTemplate, never()).send(any(String.class), any(String.class), any(AlertEvent.class));
    }

    @Test
    void listenerSkipsAlreadyProcessedEvent() {
        when(idempotencyService.markProcessedIfNew("evt-dup")).thenReturn(false);
        MonitoringEvent event = new MonitoringEvent("evt-dup", UUID.randomUUID().toString(), "web-01",
                MonitoringEventType.CPU_USAGE, "cpu.usage.percent", 99.0, Instant.now(), Map.of());

        evaluationService.onMonitoringEvent(event);

        verify(ruleService, never()).activeRulesForTenant(any());
    }

    @Test
    void alertEventCarriesTriggeringEventAndRuleData() {
        UUID tenantId = UUID.randomUUID();
        UUID ruleId = UUID.randomUUID();
        AlertRule rule = new AlertRule(ruleId, tenantId, "High CPU", "cpu.usage.percent",
                RuleComparator.GREATER_THAN, 90.0, AlertSeverity.CRITICAL, true, Instant.now());
        when(ruleService.activeRulesForTenant(tenantId)).thenReturn(List.of(rule));

        MonitoringEvent event = new MonitoringEvent("evt-3", tenantId.toString(), "web-01",
                MonitoringEventType.CPU_USAGE, "cpu.usage.percent", 95.0, Instant.now(), Map.of());

        evaluationService.evaluate(event);

        var captor = org.mockito.ArgumentCaptor.forClass(AlertEvent.class);
        verify(alertKafkaTemplate).send(eq("streampulse.alerts"), eq(tenantId.toString()), captor.capture());
        AlertEvent alert = captor.getValue();
        assertThat(alert.ruleId()).isEqualTo(ruleId.toString());
        assertThat(alert.triggeringEventId()).isEqualTo("evt-3");
        assertThat(alert.actualValue()).isEqualTo(95.0);
        assertThat(alert.severity()).isEqualTo(AlertSeverity.CRITICAL);
    }
}
