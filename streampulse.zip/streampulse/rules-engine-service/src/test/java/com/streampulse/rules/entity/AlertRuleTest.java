package com.streampulse.rules.entity;

import static org.assertj.core.api.Assertions.assertThat;

import com.streampulse.contracts.event.AlertSeverity;
import java.time.Instant;
import java.util.UUID;
import org.junit.jupiter.api.Test;

class AlertRuleTest {

    @Test
    void matchesWhenMetricNameEqualAndThresholdBreached() {
        AlertRule rule = new AlertRule(UUID.randomUUID(), UUID.randomUUID(), "High CPU", "cpu.usage.percent",
                RuleComparator.GREATER_THAN, 90.0, AlertSeverity.CRITICAL, true, Instant.now());

        assertThat(rule.matches("cpu.usage.percent", 95.0)).isTrue();
        assertThat(rule.matches("cpu.usage.percent", 85.0)).isFalse();
    }

    @Test
    void doesNotMatchDifferentMetric() {
        AlertRule rule = new AlertRule(UUID.randomUUID(), UUID.randomUUID(), "High CPU", "cpu.usage.percent",
                RuleComparator.GREATER_THAN, 90.0, AlertSeverity.CRITICAL, true, Instant.now());

        assertThat(rule.matches("memory.usage.percent", 99.0)).isFalse();
    }

    @Test
    void disabledRuleNeverMatches() {
        AlertRule rule = new AlertRule(UUID.randomUUID(), UUID.randomUUID(), "High CPU", "cpu.usage.percent",
                RuleComparator.GREATER_THAN, 90.0, AlertSeverity.CRITICAL, false, Instant.now());

        assertThat(rule.matches("cpu.usage.percent", 99.0)).isFalse();
    }

    @Test
    void lessThanOrEqualComparatorBreaches() {
        AlertRule rule = new AlertRule(UUID.randomUUID(), UUID.randomUUID(), "Low disk", "disk.free.percent",
                RuleComparator.LESS_THAN_OR_EQUAL, 10.0, AlertSeverity.WARNING, true, Instant.now());

        assertThat(rule.matches("disk.free.percent", 10.0)).isTrue();
        assertThat(rule.matches("disk.free.percent", 10.1)).isFalse();
    }
}
