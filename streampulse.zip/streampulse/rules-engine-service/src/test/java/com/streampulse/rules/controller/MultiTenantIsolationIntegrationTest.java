package com.streampulse.rules.controller;

import static org.assertj.core.api.Assertions.assertThat;

import com.streampulse.rules.dto.RuleRequest;
import com.streampulse.rules.dto.RuleResponse;
import com.streampulse.contracts.event.AlertSeverity;
import com.streampulse.rules.entity.RuleComparator;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.testcontainers.containers.GenericContainer;
import org.testcontainers.containers.PostgreSQLContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;
import org.testcontainers.utility.DockerImageName;

/**
 * Proves tenant data separation under simultaneous concurrent load: N tenants create rules in
 * parallel and each tenant's list endpoint must return exactly its own rules, never another
 * tenant's. Requires Docker; see repo README for the honest status of this run.
 */
@Testcontainers
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class MultiTenantIsolationIntegrationTest {

    @Container
    static PostgreSQLContainer<?> postgres = new PostgreSQLContainer<>("postgres:16-alpine")
            .withDatabaseName("rulesdb")
            .withUsername("streampulse")
            .withPassword("streampulse");

    @Container
    static GenericContainer<?> redis = new GenericContainer<>(DockerImageName.parse("redis:7-alpine")).withExposedPorts(6379);

    @DynamicPropertySource
    static void properties(DynamicPropertyRegistry registry) {
        registry.add("spring.datasource.url", postgres::getJdbcUrl);
        registry.add("spring.datasource.username", postgres::getUsername);
        registry.add("spring.datasource.password", postgres::getPassword);
        registry.add("spring.data.redis.host", redis::getHost);
        registry.add("spring.data.redis.port", () -> redis.getMappedPort(6379));
    }

    @LocalServerPort
    private int port;

    @Autowired
    private TestRestTemplate restTemplate;

    @Test
    void concurrentTenantsNeverSeeEachOthersRules() throws InterruptedException {
        int tenantCount = 8;
        List<UUID> tenantIds = java.util.stream.IntStream.range(0, tenantCount)
                .mapToObj(i -> UUID.randomUUID())
                .toList();

        ExecutorService pool = Executors.newFixedThreadPool(tenantCount);
        CountDownLatch latch = new CountDownLatch(tenantCount);
        AtomicInteger failures = new AtomicInteger();

        for (UUID tenantId : tenantIds) {
            pool.submit(() -> {
                try {
                    createRule(tenantId, "rule-for-" + tenantId);
                } catch (Exception e) {
                    failures.incrementAndGet();
                } finally {
                    latch.countDown();
                }
            });
        }
        latch.await(30, TimeUnit.SECONDS);
        pool.shutdown();

        assertThat(failures.get()).isZero();

        for (UUID tenantId : tenantIds) {
            List<RuleResponse> rules = listRules(tenantId);
            assertThat(rules).hasSize(1);
            assertThat(rules.get(0).name()).isEqualTo("rule-for-" + tenantId);
        }
    }

    private void createRule(UUID tenantId, String name) {
        RuleRequest request = new RuleRequest(name, "cpu.usage.percent", RuleComparator.GREATER_THAN, 90.0, AlertSeverity.CRITICAL, true);
        HttpHeaders headers = headersFor(tenantId);
        ResponseEntity<RuleResponse> response = restTemplate.postForEntity(url("/api/v1/rules"), new HttpEntity<>(request, headers), RuleResponse.class);
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.CREATED);
    }

    private List<RuleResponse> listRules(UUID tenantId) {
        ResponseEntity<RuleResponse[]> response = restTemplate.exchange(
                url("/api/v1/rules"), org.springframework.http.HttpMethod.GET,
                new HttpEntity<>(headersFor(tenantId)), RuleResponse[].class);
        return List.of(response.getBody());
    }

    private HttpHeaders headersFor(UUID tenantId) {
        HttpHeaders headers = new HttpHeaders();
        headers.add("X-Tenant-Id", tenantId.toString());
        headers.add("X-User-Id", "user-" + tenantId);
        headers.add("X-User-Roles", "ADMIN");
        return headers;
    }

    private String url(String path) {
        return "http://localhost:" + port + path;
    }
}
