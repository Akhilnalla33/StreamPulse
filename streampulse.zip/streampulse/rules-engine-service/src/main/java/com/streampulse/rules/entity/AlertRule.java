package com.streampulse.rules.entity;

import com.streampulse.contracts.event.AlertSeverity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Version;
import java.io.Serializable;
import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name = "alert_rules")
public class AlertRule implements Serializable {

    @Id
    private UUID id;

    @Column(name = "tenant_id", nullable = false)
    private UUID tenantId;

    @Column(nullable = false)
    private String name;

    @Column(name = "metric_name", nullable = false)
    private String metricName;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private RuleComparator comparator;

    @Column(nullable = false)
    private double threshold;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private AlertSeverity severity;

    @Column(nullable = false)
    private boolean enabled;

    @Column(name = "created_at", nullable = false)
    private Instant createdAt;

    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt;

    @Version
    private Long version;

    protected AlertRule() {
    }

    public AlertRule(UUID id, UUID tenantId, String name, String metricName, RuleComparator comparator,
                      double threshold, AlertSeverity severity, boolean enabled, Instant now) {
        this.id = id;
        this.tenantId = tenantId;
        this.name = name;
        this.metricName = metricName;
        this.comparator = comparator;
        this.threshold = threshold;
        this.severity = severity;
        this.enabled = enabled;
        this.createdAt = now;
        this.updatedAt = now;
    }

    public void applyUpdate(String name, String metricName, RuleComparator comparator, double threshold,
                             AlertSeverity severity, boolean enabled, Instant now) {
        this.name = name;
        this.metricName = metricName;
        this.comparator = comparator;
        this.threshold = threshold;
        this.severity = severity;
        this.enabled = enabled;
        this.updatedAt = now;
    }

    public boolean matches(String metricName, double actualValue) {
        return enabled && this.metricName.equals(metricName) && comparator.breaches(actualValue, threshold);
    }

    public UUID getId() {
        return id;
    }

    public UUID getTenantId() {
        return tenantId;
    }

    public String getName() {
        return name;
    }

    public String getMetricName() {
        return metricName;
    }

    public RuleComparator getComparator() {
        return comparator;
    }

    public double getThreshold() {
        return threshold;
    }

    public AlertSeverity getSeverity() {
        return severity;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public Instant getUpdatedAt() {
        return updatedAt;
    }

    public Long getVersion() {
        return version;
    }
}
