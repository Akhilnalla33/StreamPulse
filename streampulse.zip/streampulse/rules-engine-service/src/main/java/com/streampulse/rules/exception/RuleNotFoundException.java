package com.streampulse.rules.exception;

import java.util.UUID;

public class RuleNotFoundException extends RuntimeException {

    public RuleNotFoundException(UUID ruleId) {
        super("Alert rule not found: " + ruleId);
    }
}
