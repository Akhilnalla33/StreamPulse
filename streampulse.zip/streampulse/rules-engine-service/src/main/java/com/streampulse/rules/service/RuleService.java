package com.streampulse.rules.service;

import com.streampulse.rules.dto.RuleRequest;
import com.streampulse.rules.entity.AlertRule;
import com.streampulse.rules.exception.RuleNotFoundException;
import com.streampulse.rules.repository.AlertRuleRepository;
import java.time.Instant;
import java.util.List;
import java.util.UUID;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class RuleService {

    private final AlertRuleRepository repository;

    public RuleService(AlertRuleRepository repository) {
        this.repository = repository;
    }

    @Transactional
    @CacheEvict(value = "rule-cache", key = "#tenantId")
    public AlertRule create(UUID tenantId, RuleRequest request) {
        AlertRule rule = new AlertRule(
                UUID.randomUUID(), tenantId, request.name(), request.metricName(), request.comparator(),
                request.threshold(), request.severity(), request.enabled(), Instant.now());
        return repository.save(rule);
    }

    @Transactional
    @CacheEvict(value = "rule-cache", key = "#tenantId")
    public AlertRule update(UUID tenantId, UUID ruleId, RuleRequest request) {
        AlertRule rule = repository.findByIdAndTenantId(ruleId, tenantId)
                .orElseThrow(() -> new RuleNotFoundException(ruleId));
        rule.applyUpdate(request.name(), request.metricName(), request.comparator(), request.threshold(),
                request.severity(), request.enabled(), Instant.now());
        return repository.save(rule);
    }

    @Transactional
    @CacheEvict(value = "rule-cache", key = "#tenantId")
    public void delete(UUID tenantId, UUID ruleId) {
        AlertRule rule = repository.findByIdAndTenantId(ruleId, tenantId)
                .orElseThrow(() -> new RuleNotFoundException(ruleId));
        repository.delete(rule);
    }

    @Transactional(readOnly = true)
    public List<AlertRule> listAll(UUID tenantId) {
        return repository.findByTenantId(tenantId);
    }

    @Transactional(readOnly = true)
    public AlertRule get(UUID tenantId, UUID ruleId) {
        return repository.findByIdAndTenantId(ruleId, tenantId).orElseThrow(() -> new RuleNotFoundException(ruleId));
    }

    /** Cached per {@code docs/CONTRACT.md}: {@code rule-cache:{tenantId}}, TTL 60s, evicted on any write above. */
    @Cacheable(value = "rule-cache", key = "#tenantId")
    @Transactional(readOnly = true)
    public List<AlertRule> activeRulesForTenant(UUID tenantId) {
        return repository.findByTenantIdAndEnabledTrue(tenantId);
    }
}
