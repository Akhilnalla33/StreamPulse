package com.streampulse.rules.service;

import com.streampulse.contracts.event.AlertEvent;
import com.streampulse.contracts.event.MonitoringEvent;
import com.streampulse.rules.config.KafkaTopicConfig;
import com.streampulse.rules.entity.AlertRule;
import java.time.Instant;
import java.util.List;
import java.util.UUID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

/**
 * Consumes {@link MonitoringEvent}s from {@code streampulse.events} and evaluates each against
 * the owning tenant's cached active rules, publishing an {@link AlertEvent} to
 * {@code streampulse.alerts} for every rule that breaches.
 */
@Service
public class RuleEvaluationService {

    private static final Logger log = LoggerFactory.getLogger(RuleEvaluationService.class);

    private final RuleService ruleService;
    private final IdempotencyService idempotencyService;
    private final KafkaTemplate<String, AlertEvent> alertKafkaTemplate;

    public RuleEvaluationService(RuleService ruleService, IdempotencyService idempotencyService,
                                  KafkaTemplate<String, AlertEvent> alertKafkaTemplate) {
        this.ruleService = ruleService;
        this.idempotencyService = idempotencyService;
        this.alertKafkaTemplate = alertKafkaTemplate;
    }

    @KafkaListener(topics = KafkaTopicConfig.EVENTS_TOPIC, groupId = "rules-engine")
    public void onMonitoringEvent(MonitoringEvent event) {
        if (!idempotencyService.markProcessedIfNew(event.eventId())) {
            log.debug("Skipping already-processed event {}", event.eventId());
            return;
        }
        evaluate(event);
    }

    void evaluate(MonitoringEvent event) {
        UUID tenantId = UUID.fromString(event.tenantId());
        List<AlertRule> rules = ruleService.activeRulesForTenant(tenantId);

        for (AlertRule rule : rules) {
            if (rule.matches(event.metricName(), event.value())) {
                AlertEvent alert = new AlertEvent(
                        UUID.randomUUID().toString(),
                        event.tenantId(),
                        rule.getId().toString(),
                        rule.getName(),
                        rule.getSeverity(),
                        event.metricName(),
                        rule.getThreshold(),
                        event.value(),
                        event.eventId(),
                        buildMessage(rule, event),
                        Instant.now());
                alertKafkaTemplate.send(KafkaTopicConfig.ALERTS_TOPIC, event.tenantId(), alert);
            }
        }
    }

    private String buildMessage(AlertRule rule, MonitoringEvent event) {
        return "%s: %s %s %.2f (actual %.2f)".formatted(
                rule.getName(), event.metricName(), rule.getComparator(), rule.getThreshold(), event.value());
    }
}
