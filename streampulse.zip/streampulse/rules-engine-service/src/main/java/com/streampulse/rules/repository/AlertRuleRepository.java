package com.streampulse.rules.repository;

import com.streampulse.rules.entity.AlertRule;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AlertRuleRepository extends JpaRepository<AlertRule, UUID> {
    List<AlertRule> findByTenantIdAndEnabledTrue(UUID tenantId);

    List<AlertRule> findByTenantId(UUID tenantId);

    Optional<AlertRule> findByIdAndTenantId(UUID id, UUID tenantId);
}
