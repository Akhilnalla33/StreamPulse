package com.streampulse.rules.service;

import java.time.Duration;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

/**
 * Redis-backed dedupe so re-delivered Kafka messages (at-least-once semantics) don't fire the
 * same alert twice. Key layout: {@code idempotency:events:{eventId}}, TTL 24h (docs/CONTRACT.md).
 */
@Service
public class IdempotencyService {

    private static final String KEY_PREFIX = "idempotency:events:";
    private static final Duration TTL = Duration.ofHours(24);

    private final StringRedisTemplate redisTemplate;

    public IdempotencyService(StringRedisTemplate redisTemplate) {
        this.redisTemplate = redisTemplate;
    }

    /** Returns true the first time it is called for a given eventId; false on any repeat. */
    public boolean markProcessedIfNew(String eventId) {
        Boolean wasAbsent = redisTemplate.opsForValue().setIfAbsent(KEY_PREFIX + eventId, "1", TTL);
        return Boolean.TRUE.equals(wasAbsent);
    }
}
