package com.streampulse.rules.entity;

import java.util.function.DoubleBinaryOperator;

public enum RuleComparator {
    GREATER_THAN((actual, threshold) -> actual > threshold ? 1 : 0),
    GREATER_THAN_OR_EQUAL((actual, threshold) -> actual >= threshold ? 1 : 0),
    LESS_THAN((actual, threshold) -> actual < threshold ? 1 : 0),
    LESS_THAN_OR_EQUAL((actual, threshold) -> actual <= threshold ? 1 : 0);

    private final DoubleBinaryOperator predicate;

    RuleComparator(DoubleBinaryOperator predicate) {
        this.predicate = predicate;
    }

    public boolean breaches(double actualValue, double threshold) {
        return predicate.applyAsDouble(actualValue, threshold) == 1;
    }
}
