CREATE TABLE alert_rules (
    id            UUID PRIMARY KEY,
    tenant_id     UUID NOT NULL,
    name          VARCHAR(255) NOT NULL,
    metric_name   VARCHAR(255) NOT NULL,
    comparator    VARCHAR(30) NOT NULL,
    threshold     DOUBLE PRECISION NOT NULL,
    severity      VARCHAR(20) NOT NULL,
    enabled       BOOLEAN NOT NULL DEFAULT TRUE,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    version       BIGINT NOT NULL DEFAULT 0
);

CREATE INDEX idx_alert_rules_tenant_metric ON alert_rules (tenant_id, metric_name) WHERE enabled = TRUE;
